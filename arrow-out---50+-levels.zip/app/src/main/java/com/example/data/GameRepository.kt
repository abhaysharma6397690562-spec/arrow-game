package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class GameRepository(private val gameDao: GameDao) {

    val allProgress: Flow<List<LevelProgressEntity>> = gameDao.getAllLevelProgress()
    val playerProfile: Flow<PlayerProfileEntity?> = gameDao.getPlayerProfile()

    suspend fun initializeProgressIfEmpty(totalLevels: Int) {
        val existing = allProgress.firstOrNull()
        if (existing.isNullOrEmpty()) {
            val initialList = (1..totalLevels).map { levelNum ->
                LevelProgressEntity(
                    levelNumber = levelNum,
                    stars = 0,
                    bestMoves = 0,
                    bestTimeSeconds = 0,
                    isUnlocked = (levelNum == 1) // First level is unlocked initially
                )
            }
            gameDao.insertAllLevels(initialList)
            gameDao.savePlayerProfile(PlayerProfileEntity())
        }
    }

    suspend fun saveLevelCompletion(
        levelNumber: Int,
        stars: Int,
        moves: Int,
        timeSeconds: Int,
        nextLevelNumber: Int?
    ) {
        val current = gameDao.getLevelProgress(levelNumber)
        val bestStars = if (current != null) maxOf(current.stars, stars) else stars
        val bestMoves = if (current != null && current.bestMoves > 0) minOf(current.bestMoves, moves) else moves
        val bestTime = if (current != null && current.bestTimeSeconds > 0) minOf(current.bestTimeSeconds, timeSeconds) else timeSeconds

        gameDao.insertOrUpdateLevel(
            LevelProgressEntity(
                levelNumber = levelNumber,
                stars = bestStars,
                bestMoves = bestMoves,
                bestTimeSeconds = bestTime,
                isUnlocked = true,
                completedAt = System.currentTimeMillis()
            )
        )

        // Unlock next level if present
        if (nextLevelNumber != null) {
            gameDao.unlockLevel(nextLevelNumber)
        }

        // Update profile last played level
        val profile = playerProfile.firstOrNull() ?: PlayerProfileEntity()
        gameDao.savePlayerProfile(profile.copy(lastPlayedLevel = nextLevelNumber ?: levelNumber))
    }

    suspend fun updateSoundSetting(enabled: Boolean) {
        val profile = playerProfile.firstOrNull() ?: PlayerProfileEntity()
        gameDao.savePlayerProfile(profile.copy(soundEnabled = enabled))
    }

    suspend fun updateHapticsSetting(enabled: Boolean) {
        val profile = playerProfile.firstOrNull() ?: PlayerProfileEntity()
        gameDao.savePlayerProfile(profile.copy(hapticsEnabled = enabled))
    }

    suspend fun saveArcadeHighScore(score: Int, streak: Int) {
        val profile = playerProfile.firstOrNull() ?: PlayerProfileEntity()
        val high = maxOf(profile.arcadeHighScore, score)
        val bestStreak = maxOf(profile.arcadeBestStreak, streak)
        gameDao.savePlayerProfile(profile.copy(arcadeHighScore = high, arcadeBestStreak = bestStreak))
    }

    suspend fun incrementHintUsed() {
        val profile = playerProfile.firstOrNull() ?: PlayerProfileEntity()
        gameDao.savePlayerProfile(profile.copy(totalHintsUsed = profile.totalHintsUsed + 1))
    }

    suspend fun resetAllProgress(totalLevels: Int) {
        gameDao.clearAllProgress()
        val initialList = (1..totalLevels).map { levelNum ->
            LevelProgressEntity(
                levelNumber = levelNum,
                stars = 0,
                bestMoves = 0,
                bestTimeSeconds = 0,
                isUnlocked = (levelNum == 1)
            )
        }
        gameDao.insertAllLevels(initialList)
        gameDao.savePlayerProfile(PlayerProfileEntity())
    }
}
