package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "level_progress")
data class LevelProgressEntity(
    @PrimaryKey val levelNumber: Int,
    val stars: Int = 0,
    val bestMoves: Int = 0,
    val bestTimeSeconds: Int = 0,
    val isUnlocked: Boolean = false,
    val completedAt: Long = 0L
)

@Entity(tableName = "player_profile")
data class PlayerProfileEntity(
    @PrimaryKey val id: Int = 1,
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val totalHintsUsed: Int = 0,
    val arcadeHighScore: Int = 0,
    val arcadeBestStreak: Int = 0,
    val lastPlayedLevel: Int = 1
)
