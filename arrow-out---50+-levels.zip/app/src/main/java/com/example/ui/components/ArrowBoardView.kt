package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.model.Arrow
import com.example.model.ArrowDirection
import com.example.model.ArrowType
import com.example.model.Obstacle
import com.example.model.ObstacleType

// Color palette for arrows and interactive tiles
val ArrowPalette = listOf(
    Color(0xFF00E5FF), // Cyan
    Color(0xFFFFB300), // Amber
    Color(0xFF10B981), // Emerald
    Color(0xFFF43F5E), // Rose
    Color(0xFFA855F7)  // Purple
)

@Composable
fun ArrowBoardView(
    rows: Int,
    cols: Int,
    arrows: List<Arrow>,
    obstacles: List<Obstacle>,
    activeHintId: Int?,
    onArrowTapped: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(cols.toFloat() / rows.toFloat())
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A)),
                    center = Offset(500f, 500f),
                    radius = 800f
                )
            )
            .border(2.dp, Color(0xFF334155), RoundedCornerShape(24.dp))
            .padding(12.dp)
    ) {
        val cellWidth = maxWidth / cols
        val cellHeight = maxHeight / rows

        // Board background subtle grid pattern
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cellW = size.width / cols
            val cellH = size.height / rows

            // Draw grid dots / subtle tiles
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val cx = c * cellW + cellW / 2
                    val cy = r * cellH + cellH / 2
                    drawCircle(
                        color = Color(0x1A94A3B8),
                        radius = 3.dp.toPx(),
                        center = Offset(cx, cy)
                    )
                }
            }
        }

        // Render Obstacles (Walls, Doors, Portals, Rotators)
        obstacles.filter { !it.isDestroyed }.forEach { obstacle ->
            Box(
                modifier = Modifier
                    .size(cellWidth, cellHeight)
                    .graphicsLayer {
                        translationX = obstacle.col * cellWidth.toPx()
                        translationY = obstacle.row * cellHeight.toPx()
                    }
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                ObstacleView(obstacle = obstacle)
            }
        }

        // Render Interactive Arrows
        arrows.filter { !it.isEscaped }.forEach { arrow ->
            val isHinted = arrow.id == activeHintId

            Box(
                modifier = Modifier
                    .size(cellWidth, cellHeight)
                    .graphicsLayer {
                        translationX = (arrow.col + arrow.collisionOffsetCol) * cellWidth.toPx()
                        translationY = (arrow.row + arrow.collisionOffsetRow) * cellHeight.toPx()
                    }
                    .padding(3.dp),
                contentAlignment = Alignment.Center
            ) {
                ArrowItemView(
                    arrow = arrow,
                    isHinted = isHinted,
                    onTap = { onArrowTapped(arrow.id) }
                )
            }
        }
    }
}

@Composable
fun ArrowItemView(
    arrow: Arrow,
    isHinted: Boolean,
    onTap: () -> Unit
) {
    val arrowColor = ArrowPalette[arrow.colorIndex % ArrowPalette.size]

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isHinted) 1.25f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hintPulse"
    )

    val bounceScale = remember { Animatable(1f) }
    LaunchedEffect(arrow.isColliding) {
        if (arrow.isColliding) {
            bounceScale.animateTo(0.85f, animationSpec = tween(70))
            bounceScale.animateTo(1f, animationSpec = spring(dampingRatio = 0.45f, stiffness = 800f))
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                scaleX = bounceScale.value * if (isHinted) pulseScale else 1f
                scaleY = bounceScale.value * if (isHinted) pulseScale else 1f
            }
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.linearGradient(
                    colors = if (isHinted) {
                        listOf(Color(0xFFFFD700), Color(0xFFFFA000))
                    } else {
                        listOf(Color(0xFF26334D), Color(0xFF1E283E))
                    }
                )
            )
            .border(
                width = if (isHinted) 2.5.dp else 1.5.dp,
                color = if (isHinted) Color(0xFFFFD54F) else arrowColor.copy(alpha = 0.65f),
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onTap
            )
            .semantics { contentDescription = "Arrow ${arrow.direction} at row ${arrow.row} col ${arrow.col}" }
            .testTag("arrow_${arrow.id}"),
        contentAlignment = Alignment.Center
    ) {
        // Arrow Graphic drawn on Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp)
                .rotate(arrow.direction.angleDegrees)
        ) {
            drawStylizedArrow(
                color = if (isHinted) Color(0xFF1A1A1A) else arrowColor,
                type = arrow.type
            )
        }

        // Secondary Badge (for Keys or Bombs)
        when (arrow.type) {
            ArrowType.KEY -> {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFFD700))
                        .align(Alignment.BottomEnd),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = "Key Arrow",
                        tint = Color(0xFF1A1A1A),
                        modifier = Modifier.size(11.dp)
                    )
                }
            }
            ArrowType.BOMB -> {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFEF4444))
                        .align(Alignment.BottomEnd),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(8.dp)) {
                        drawCircle(color = Color.White)
                    }
                }
            }
            ArrowType.TURN_RIGHT, ArrowType.TURN_LEFT -> {
                // Curved indicator icon in corner
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(Color(0x5500E5FF))
                        .align(Alignment.BottomEnd),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Turn Arrow",
                        tint = Color.White,
                        modifier = Modifier
                            .size(10.dp)
                            .rotate(if (arrow.type == ArrowType.TURN_LEFT) -90f else 90f)
                    )
                }
            }
            else -> {}
        }
    }
}

private fun DrawScope.drawStylizedArrow(color: Color, type: ArrowType) {
    val w = size.width
    val h = size.height
    val cx = w / 2f
    val cy = h / 2f

    val arrowHeadPath = Path().apply {
        // Pointing Upward by default, rotation handled by modifier
        moveTo(cx, h * 0.14f)
        lineTo(w * 0.82f, h * 0.52f)
        lineTo(w * 0.62f, h * 0.50f)
        lineTo(w * 0.62f, h * 0.84f)
        lineTo(w * 0.38f, h * 0.84f)
        lineTo(w * 0.38f, h * 0.50f)
        lineTo(w * 0.18f, h * 0.52f)
        close()
    }

    // Shadow / glow
    drawPath(
        path = arrowHeadPath,
        color = color.copy(alpha = 0.25f),
        style = Stroke(width = 6f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    // Solid filled arrow body
    drawPath(
        path = arrowHeadPath,
        brush = Brush.verticalGradient(
            colors = listOf(color, color.copy(alpha = 0.85f)),
            startY = 0f,
            endY = h
        )
    )

    // Highlight center spine
    drawLine(
        color = Color.White.copy(alpha = 0.7f),
        start = Offset(cx, h * 0.18f),
        end = Offset(cx, h * 0.78f),
        strokeWidth = 2.5f,
        cap = StrokeCap.Round
    )
}

@Composable
fun ObstacleView(obstacle: Obstacle) {
    when (obstacle.type) {
        ObstacleType.WALL -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF64748B), Color(0xFF334155))
                        )
                    )
                    .border(1.5.dp, Color(0xFF94A3B8), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Diagonal cross hatch
                Canvas(modifier = Modifier.fillMaxSize().padding(4.dp)) {
                    drawLine(
                        color = Color(0x33FFFFFF),
                        start = Offset(0f, 0f),
                        end = Offset(size.width, size.height),
                        strokeWidth = 2.dp.toPx()
                    )
                    drawLine(
                        color = Color(0x33FFFFFF),
                        start = Offset(size.width, 0f),
                        end = Offset(0f, size.height),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }
        }
        ObstacleType.LOCK_DOOR -> {
            val gateColor = ArrowPalette[obstacle.colorIndex % ArrowPalette.size]
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1E293B))
                    .border(2.dp, gateColor, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Locked Gate",
                    tint = gateColor,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
        ObstacleType.PORTAL_NODE -> {
            val infiniteTransition = rememberInfiniteTransition(label = "portal")
            val portalRotation by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 360f,
                animationSpec = infiniteRepeatable(
                    animation = tween(2200, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "portalRot"
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(Color(0xFF0F172A))
                    .border(1.5.dp, Color(0xFF00E5FF), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(4.dp)
                        .rotate(portalRotation)
                ) {
                    drawCircle(
                        brush = Brush.sweepGradient(
                            listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF), Color(0xFF00E5FF))
                        ),
                        style = Stroke(width = 3.dp.toPx())
                    )
                }
            }
        }
        ObstacleType.ROTATOR -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x3300E5FF))
                    .border(1.dp, Color(0xFF00E5FF), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Rotator Tile",
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
