package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF0284C7)
val SkyBlue = Color(0xFF38BDF8)
val DarkNavy = Color(0xFF0F172A)
val SlateCard = Color(0xFF1E293B)
val BorderSlate = Color(0xFF334155)
val AmberGold = Color(0xFFFFB300)
val BrightYellow = Color(0xFFFFD54F)
val EmeraldGreen = Color(0xFF10B981)
val RoseRed = Color(0xFFF43F5E)
val PurpleAccent = Color(0xFF8B5CF6)
