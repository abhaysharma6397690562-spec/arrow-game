package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.levels.WorldDefinitions
import com.example.model.AppScreen
import com.example.ui.components.ArrowBoardView
import com.example.ui.components.LevelCompleteDialog
import com.example.viewmodel.GameUiState

@Composable
fun GameScreen(
    state: GameUiState,
    onArrowTapped: (Int) -> Unit,
    onUndo: () -> Unit,
    onRestart: () -> Unit,
    onRequestHint: () -> Unit,
    onNextLevel: () -> Unit,
    onToggleSound: () -> Unit,
    onNavigateBack: () -> Unit
) {
    BackHandler {
        onNavigateBack()
    }

    val levelData = state.levelData
    val worldInfo = WorldDefinitions.getWorldForLevel(state.currentLevelNumber)
    val worldColor = Color(worldInfo.primaryColorHex)

    // Current star estimate based on moves vs par
    val par = levelData?.parMoves ?: 10
    val estimatedStars = when {
        state.movesCount <= par -> 3
        state.movesCount <= par + 3 -> 2
        else -> 1
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF0F172A), Color(0xFF020617))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("game_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // --- TOP BAR ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1E293B))
                        .testTag("game_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Levels",
                        tint = Color.White
                    )
                }

                // Level & World Badge
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "LEVEL ${state.currentLevelNumber}",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = levelData?.title ?: worldInfo.name,
                        color = worldColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Sound Toggle
                IconButton(
                    onClick = onToggleSound,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1E293B))
                        .testTag("game_sound_toggle")
                ) {
                    Icon(
                        imageVector = if (state.soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                        contentDescription = "Toggle Sound",
                        tint = if (state.soundEnabled) Color(0xFF38BDF8) else Color(0xFF64748B)
                    )
                }
            }

            // --- STATUS BAR (Stars, Moves, Timer) ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1E293B))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Stars indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    for (i in 1..3) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Star",
                            tint = if (i <= estimatedStars) Color(0xFFFFC107) else Color(0x33FFFFFF),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Box(modifier = Modifier.width(1.dp).height(20.dp).background(Color(0xFF334155)))

                // Moves counter vs Par
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("MOVES: ", color = Color(0xFF94A3B8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("${state.movesCount}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                    Text(" / $par", color = Color(0xFF64748B), fontSize = 12.sp)
                }

                Box(modifier = Modifier.width(1.dp).height(20.dp).background(Color(0xFF334155)))

                // Timer
                val mins = state.timeElapsedSeconds / 60
                val secs = state.timeElapsedSeconds % 60
                Text(
                    text = String.format("%02d:%02d", mins, secs),
                    color = Color(0xFF38BDF8),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Optional Tutorial banner
            AnimatedVisibility(visible = levelData?.tutorialTip != null) {
                levelData?.tutorialTip?.let { tip ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(worldColor.copy(alpha = 0.12f))
                            .border(1.dp, worldColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = worldColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = tip,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // --- THE ARROW PUZZLE BOARD ---
            if (levelData != null) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    ArrowBoardView(
                        rows = levelData.rows,
                        cols = levelData.cols,
                        arrows = state.arrows,
                        obstacles = state.obstacles,
                        activeHintId = state.activeHintArrowId,
                        onArrowTapped = onArrowTapped,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            } else {
                Spacer(modifier = Modifier.weight(1f))
            }

            // Remaining Arrows Progress Count
            val remainingArrows = state.arrows.count { !it.isEscaped }
            val totalArrows = state.arrows.size
            Text(
                text = "$remainingArrows of $totalArrows arrows remaining",
                color = Color(0xFF94A3B8),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            // --- BOTTOM CONTROLS ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Restart Button
                Surface(
                    onClick = onRestart,
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF1E293B),
                    modifier = Modifier.size(54.dp).testTag("game_restart_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Restart Level",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // Undo Button
                Surface(
                    onClick = onUndo,
                    enabled = state.canUndo,
                    shape = RoundedCornerShape(16.dp),
                    color = if (state.canUndo) Color(0xFF1E293B) else Color(0xFF0F172A),
                    modifier = Modifier.size(54.dp).testTag("game_undo_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo Move",
                            tint = if (state.canUndo) Color(0xFF38BDF8) else Color(0xFF475569),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // Hint Button (Glowing aura)
                Surface(
                    onClick = onRequestHint,
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF854D0E),
                    modifier = Modifier
                        .size(54.dp)
                        .border(1.5.dp, Color(0xFFFACC15), RoundedCornerShape(16.dp))
                        .testTag("game_hint_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = "Get Hint",
                            tint = Color(0xFFFDE047),
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
        }

        // --- VICTORY POPUP ---
        if (state.isLevelCompleted && levelData != null) {
            LevelCompleteDialog(
                levelNumber = state.currentLevelNumber,
                starsEarned = state.earnedStars,
                movesTaken = state.movesCount,
                parMoves = levelData.parMoves,
                timeSeconds = state.timeElapsedSeconds,
                onNextLevel = onNextLevel,
                onReplay = onRestart,
                onLevelSelect = onNavigateBack
            )
        }
    }
}
