package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.PlayerProfileEntity
import com.example.ui.components.ArrowBoardView
import com.example.viewmodel.GameUiState

@Composable
fun ArcadeScreen(
    state: GameUiState,
    profile: PlayerProfileEntity?,
    onArrowTapped: (Int) -> Unit,
    onRestartArcade: () -> Unit,
    onNavigateBack: () -> Unit
) {
    BackHandler {
        onNavigateBack()
    }

    val highScore = profile?.arcadeHighScore ?: 0

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF1E112A), Color(0xFF0D0614))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("arcade_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF2D1B3E))
                        .testTag("arcade_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "ARCADE RUSH",
                        color = Color(0xFFF43F5E),
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "High Score: $highScore",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp
                    )
                }

                // Time remaining indicator
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (state.arcadeTimeRemaining <= 10) Color(0xFFEF4444) else Color(0xFFF43F5E).copy(alpha = 0.3f))
                        .border(1.dp, Color(0xFFF43F5E), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "${state.arcadeTimeRemaining}s",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp
                    )
                }
            }

            // Live Score & Streak Pill
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF2D1B3E))
                    .border(1.dp, Color(0xFF831843), RoundedCornerShape(16.dp))
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SCORE", color = Color(0xFFCBD5E1), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("${state.arcadeScore}", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                }

                Box(modifier = Modifier.width(1.dp).height(30.dp).background(Color(0xFF831843)))

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("STREAK COMBO", color = Color(0xFFFB7185), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(20.dp))
                        Text("${state.arcadeStreak}x", color = Color(0xFFF59E0B), fontSize = 24.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            // 4x4 Quick Grid
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                ArrowBoardView(
                    rows = 4,
                    cols = 4,
                    arrows = state.arrows,
                    obstacles = emptyList(),
                    activeHintId = null,
                    onArrowTapped = onArrowTapped,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }

            Text(
                text = "Tap unblocked arrows fast! Combos multiply score.",
                color = Color(0xFF94A3B8),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }

        // Game Over Dialog
        if (state.arcadeGameOver) {
            Dialog(onDismissRequest = {}) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color(0xFF1E112A),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(2.dp, Color(0xFFF43F5E), RoundedCornerShape(24.dp))
                        .testTag("arcade_game_over_dialog")
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = Color(0xFFFFC107),
                            modifier = Modifier.size(56.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "TIME'S UP!",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text("FINAL SCORE", color = Color(0xFF94A3B8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("${state.arcadeScore}", color = Color(0xFFF43F5E), fontSize = 36.sp, fontWeight = FontWeight.Black)

                        if (state.arcadeScore > highScore) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "★ NEW HIGH SCORE! ★",
                                color = Color(0xFFFFC107),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = onRestartArcade,
                            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("arcade_play_again"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF43F5E))
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("PLAY AGAIN", fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Text("MAIN MENU")
                        }
                    }
                }
            }
        }
    }
}
