package com.example.model

enum class ArrowDirection(val deltaRow: Int, val deltaCol: Int, val angleDegrees: Float) {
    UP(-1, 0, 0f),
    RIGHT(0, 1, 90f),
    DOWN(1, 0, 180f),
    LEFT(0, -1, 270f),
    UP_RIGHT(-1, 1, 45f),
    DOWN_RIGHT(1, 1, 135f),
    DOWN_LEFT(1, -1, 225f),
    UP_LEFT(-1, -1, 315f);

    fun turnClockwise90(): ArrowDirection = when (this) {
        UP -> RIGHT
        RIGHT -> DOWN
        DOWN -> LEFT
        LEFT -> UP
        UP_RIGHT -> DOWN_RIGHT
        DOWN_RIGHT -> DOWN_LEFT
        DOWN_LEFT -> UP_LEFT
        UP_LEFT -> UP_RIGHT
    }

    fun turnCounterClockwise90(): ArrowDirection = when (this) {
        UP -> LEFT
        LEFT -> DOWN
        DOWN -> RIGHT
        RIGHT -> UP
        UP_RIGHT -> UP_LEFT
        UP_LEFT -> DOWN_LEFT
        DOWN_LEFT -> DOWN_RIGHT
        DOWN_RIGHT -> UP_RIGHT
    }
}

enum class ArrowType {
    NORMAL,
    TURN_RIGHT,   // Travels 1 tile, then turns 90° right
    TURN_LEFT,    // Travels 1 tile, then turns 90° left
    BOMB,         // Destroys first obstacle it hits
    KEY,          // Unlocks matching color gate when escaping
    PORTAL        // Enters a portal and teleports out another
}

enum class ObstacleType {
    WALL,         // Unbreakable rock wall
    LOCK_DOOR,    // Locked door, cleared when key arrow is removed
    ROTATOR,      // Rotating pad - rotates arrow that crosses it
    PORTAL_NODE   // Teleports arrow to twin portal
}

data class Arrow(
    val id: Int,
    val row: Int,
    val col: Int,
    val direction: ArrowDirection,
    val type: ArrowType = ArrowType.NORMAL,
    val colorIndex: Int = 0, // 0 = Cyan, 1 = Amber, 2 = Emerald, 3 = Rose, 4 = Violet
    val isEscaped: Boolean = false,
    val isColliding: Boolean = false,
    val collisionOffsetRow: Float = 0f,
    val collisionOffsetCol: Float = 0f,
    val isHinted: Boolean = false
)

data class Obstacle(
    val id: Int,
    val row: Int,
    val col: Int,
    val type: ObstacleType,
    val colorIndex: Int = 0,
    val isDestroyed: Boolean = false,
    val twinRow: Int = -1,
    val twinCol: Int = -1
)

data class StepRecord(
    val arrowId: Int,
    val previousArrows: List<Arrow>,
    val previousObstacles: List<Obstacle>
)

data class LevelData(
    val levelNumber: Int,
    val worldId: Int,
    val worldName: String,
    val title: String,
    val rows: Int,
    val cols: Int,
    val parMoves: Int,
    val arrows: List<Arrow>,
    val obstacles: List<Obstacle> = emptyList(),
    val tutorialTip: String? = null
)

data class WorldInfo(
    val id: Int,
    val name: String,
    val subtitle: String,
    val startLevel: Int,
    val endLevel: Int,
    val primaryColorHex: Long,
    val accentColorHex: Long,
    val iconName: String
)

enum class AppScreen {
    MENU,
    LEVEL_SELECT,
    GAME,
    ARCADE_MODE,
    STATS
}
