package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class SoundManager(context: Context) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(Dispatchers.Default)

    var soundEnabled: Boolean = true
    var hapticsEnabled: Boolean = true

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val sampleRate = 44100

    private fun playPcm(samples: ShortArray) {
        if (!soundEnabled) return
        scope.launch {
            try {
                val minBufferSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                val bufferSize = maxOf(samples.size * 2, minBufferSize)
                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(samples, 0, samples.size)
                audioTrack.play()
                // Auto release after sound duration
                val durationMs = (samples.size * 1000L / sampleRate) + 50
                Thread.sleep(durationMs)
                audioTrack.stop()
                audioTrack.release()
            } catch (_: Exception) {
                // Ignore audio errors gracefully
            }
        }
    }

    fun playLaunch() {
        // Frequency sweep 300Hz to 850Hz over 140ms
        val durationMs = 140
        val numSamples = (sampleRate * durationMs / 1000)
        val samples = ShortArray(numSamples)
        var phase = 0.0
        for (i in 0 until numSamples) {
            val t = i.toDouble() / numSamples
            val freq = 320.0 + (850.0 - 320.0) * (t * t)
            phase += 2.0 * PI * freq / sampleRate
            val envelope = (1.0 - t) * (1.0 - exp(-t * 20.0))
            val sample = (sin(phase) * envelope * 0.45 * Short.MAX_VALUE).toInt()
            samples[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
        vibrate(30, 80)
    }

    fun playBump() {
        // Low resonant thump 140Hz down to 60Hz over 110ms
        val durationMs = 110
        val numSamples = (sampleRate * durationMs / 1000)
        val samples = ShortArray(numSamples)
        var phase = 0.0
        for (i in 0 until numSamples) {
            val t = i.toDouble() / numSamples
            val freq = 140.0 - 80.0 * t
            phase += 2.0 * PI * freq / sampleRate
            val envelope = exp(-t * 12.0)
            val sample = (sin(phase) * envelope * 0.6 * Short.MAX_VALUE).toInt()
            samples[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
        vibrate(70, 200)
    }

    fun playVictory() {
        // Arpeggio: C5 (523Hz), E5 (659Hz), G5 (784Hz), C6 (1046Hz)
        val noteDurationMs = 120
        val totalMs = noteDurationMs * 4
        val numSamples = (sampleRate * totalMs / 1000)
        val samples = ShortArray(numSamples)
        val freqs = doubleArrayOf(523.25, 659.25, 783.99, 1046.50)

        for (n in 0 until 4) {
            val startSample = n * (sampleRate * noteDurationMs / 1000)
            val noteSamples = (sampleRate * noteDurationMs / 1000)
            var phase = 0.0
            val f = freqs[n]
            for (i in 0 until noteSamples) {
                val idx = startSample + i
                if (idx < numSamples) {
                    val t = i.toDouble() / noteSamples
                    phase += 2.0 * PI * f / sampleRate
                    val envelope = (1.0 - t * 0.5) * exp(-t * 3.0)
                    val sample = (sin(phase) * envelope * 0.4 * Short.MAX_VALUE).toInt()
                    samples[idx] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }
            }
        }
        playPcm(samples)
        vibrateVictory()
    }

    fun playStar() {
        // High crystalline chime
        val durationMs = 180
        val numSamples = (sampleRate * durationMs / 1000)
        val samples = ShortArray(numSamples)
        var phase = 0.0
        for (i in 0 until numSamples) {
            val t = i.toDouble() / numSamples
            phase += 2.0 * PI * 1318.51 / sampleRate // E6
            val envelope = exp(-t * 8.0)
            val sample = (sin(phase) * envelope * 0.35 * Short.MAX_VALUE).toInt()
            samples[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
        vibrate(25, 100)
    }

    fun playClick() {
        val durationMs = 30
        val numSamples = (sampleRate * durationMs / 1000)
        val samples = ShortArray(numSamples)
        var phase = 0.0
        for (i in 0 until numSamples) {
            val t = i.toDouble() / numSamples
            phase += 2.0 * PI * 980.0 / sampleRate
            val envelope = exp(-t * 25.0)
            val sample = (sin(phase) * envelope * 0.25 * Short.MAX_VALUE).toInt()
            samples[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
        vibrate(15, 60)
    }

    fun playExplosion() {
        // Noise burst with decay
        val durationMs = 180
        val numSamples = (sampleRate * durationMs / 1000)
        val samples = ShortArray(numSamples)
        var prev = 0.0
        for (i in 0 until numSamples) {
            val t = i.toDouble() / numSamples
            val raw = (Math.random() * 2.0 - 1.0)
            // Low-pass filter noise
            prev = prev * 0.75 + raw * 0.25
            val envelope = exp(-t * 6.0)
            val sample = (prev * envelope * 0.5 * Short.MAX_VALUE).toInt()
            samples[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        playPcm(samples)
        vibrate(100, 255)
    }

    private fun vibrate(durationMs: Long, amplitude: Int = VibrationEffect.DEFAULT_AMPLITUDE) {
        if (!hapticsEnabled || vibrator == null || !vibrator.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(durationMs, amplitude))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    private fun vibrateVictory() {
        if (!hapticsEnabled || vibrator == null || !vibrator.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val timings = longArrayOf(0, 50, 60, 70, 70, 120)
                val amplitudes = intArrayOf(0, 100, 0, 160, 0, 240)
                vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(longArrayOf(0, 60, 80, 120), -1)
            }
        } catch (_: Exception) {}
    }
}
