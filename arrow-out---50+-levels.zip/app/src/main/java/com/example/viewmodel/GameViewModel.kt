package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundManager
import com.example.data.AppDatabase
import com.example.data.GameRepository
import com.example.data.LevelProgressEntity
import com.example.data.PlayerProfileEntity
import com.example.levels.LevelCatalog
import com.example.levels.WorldDefinitions
import com.example.model.AppScreen
import com.example.model.Arrow
import com.example.model.ArrowDirection
import com.example.model.ArrowType
import com.example.model.LevelData
import com.example.model.Obstacle
import com.example.model.ObstacleType
import com.example.model.StepRecord
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class GameUiState(
    val currentScreen: AppScreen = AppScreen.MENU,
    val selectedWorldId: Int = 1,
    val currentLevelNumber: Int = 1,
    val levelData: LevelData? = null,
    val arrows: List<Arrow> = emptyList(),
    val obstacles: List<Obstacle> = emptyList(),
    val movesCount: Int = 0,
    val timeElapsedSeconds: Int = 0,
    val isLevelCompleted: Boolean = false,
    val earnedStars: Int = 0,
    val canUndo: Boolean = false,
    val activeHintArrowId: Int? = null,
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    // Arcade Mode
    val isArcadeActive: Boolean = false,
    val arcadeScore: Int = 0,
    val arcadeStreak: Int = 0,
    val arcadeTimeRemaining: Int = 60,
    val arcadeGameOver: Boolean = false
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GameRepository
    val soundManager: SoundManager

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private val undoStack = mutableListOf<StepRecord>()
    private var timerJob: Job? = null
    private var arcadeTimerJob: Job? = null

    val allProgress: StateFlow<List<LevelProgressEntity>>
    val playerProfile: StateFlow<PlayerProfileEntity?>

    init {
        val database = AppDatabase.getInstance(application)
        repository = GameRepository(database.gameDao())
        soundManager = SoundManager(application)

        allProgress = repository.allProgress.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        playerProfile = repository.playerProfile.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

        viewModelScope.launch {
            repository.initializeProgressIfEmpty(LevelCatalog.TOTAL_LEVELS)
            playerProfile.collect { profile ->
                if (profile != null) {
                    soundManager.soundEnabled = profile.soundEnabled
                    soundManager.hapticsEnabled = profile.hapticsEnabled
                    _uiState.value = _uiState.value.copy(
                        soundEnabled = profile.soundEnabled,
                        hapticsEnabled = profile.hapticsEnabled
                    )
                }
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        soundManager.playClick()
        if (screen != AppScreen.GAME && screen != AppScreen.ARCADE_MODE) {
            stopTimer()
            stopArcadeTimer()
        }
        _uiState.value = _uiState.value.copy(currentScreen = screen)
    }

    fun selectWorld(worldId: Int) {
        soundManager.playClick()
        _uiState.value = _uiState.value.copy(selectedWorldId = worldId)
    }

    fun startLevel(levelNumber: Int) {
        soundManager.playClick()
        val level = LevelCatalog.getLevel(levelNumber)
        undoStack.clear()

        _uiState.value = _uiState.value.copy(
            currentScreen = AppScreen.GAME,
            currentLevelNumber = levelNumber,
            levelData = level,
            arrows = level.arrows,
            obstacles = level.obstacles,
            movesCount = 0,
            timeElapsedSeconds = 0,
            isLevelCompleted = false,
            earnedStars = 0,
            canUndo = false,
            activeHintArrowId = null,
            selectedWorldId = level.worldId
        )

        startTimer()
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                if (!_uiState.value.isLevelCompleted && _uiState.value.currentScreen == AppScreen.GAME) {
                    _uiState.value = _uiState.value.copy(
                        timeElapsedSeconds = _uiState.value.timeElapsedSeconds + 1
                    )
                }
            }
        }
    }

    private fun stopTimer() {
        timerJob?.cancel()
        timerJob = null
    }

    fun onArrowTapped(arrowId: Int) {
        val state = _uiState.value
        if (state.isLevelCompleted) return

        val arrow = state.arrows.find { it.id == arrowId && !it.isEscaped } ?: return

        // Clear hint if tapping the hinted arrow
        if (state.activeHintArrowId == arrowId) {
            _uiState.value = _uiState.value.copy(activeHintArrowId = null)
        }

        // Check if path is clear
        val traceResult = tracePath(arrow, state.arrows, state.obstacles, state.levelData?.rows ?: 5, state.levelData?.cols ?: 5)

        if (traceResult.canEscape) {
            // Success: Arrow shoots off the board!
            undoStack.add(
                StepRecord(
                    arrowId = arrowId,
                    previousArrows = state.arrows,
                    previousObstacles = state.obstacles
                )
            )

            soundManager.playLaunch()

            val newMoves = state.movesCount + 1

            // Process any interactions (key unlocking door, bomb exploding wall)
            var updatedObstacles = state.obstacles
            if (arrow.type == ArrowType.KEY) {
                updatedObstacles = updatedObstacles.map {
                    if (it.type == ObstacleType.LOCK_DOOR && it.colorIndex == arrow.colorIndex) {
                        it.copy(isDestroyed = true)
                    } else it
                }
            } else if (arrow.type == ArrowType.BOMB && traceResult.destroyedObstacleId != null) {
                soundManager.playExplosion()
                updatedObstacles = updatedObstacles.map {
                    if (it.id == traceResult.destroyedObstacleId) {
                        it.copy(isDestroyed = true)
                    } else it
                }
            }

            // Mark arrow escaped
            val updatedArrows = state.arrows.map {
                if (it.id == arrowId) it.copy(isEscaped = true, isHinted = false) else it
            }

            val remainingUnescaped = updatedArrows.count { !it.isEscaped }
            val levelWon = remainingUnescaped == 0

            var stars = 0
            if (levelWon) {
                stopTimer()
                soundManager.playVictory()
                val par = state.levelData?.parMoves ?: 10
                stars = when {
                    newMoves <= par -> 3
                    newMoves <= par + 3 -> 2
                    else -> 1
                }

                // Save in Room database
                val nextLevel = if (state.currentLevelNumber < LevelCatalog.TOTAL_LEVELS) {
                    state.currentLevelNumber + 1
                } else null

                viewModelScope.launch {
                    repository.saveLevelCompletion(
                        levelNumber = state.currentLevelNumber,
                        stars = stars,
                        moves = newMoves,
                        timeSeconds = state.timeElapsedSeconds,
                        nextLevelNumber = nextLevel
                    )
                }
            }

            _uiState.value = state.copy(
                arrows = updatedArrows,
                obstacles = updatedObstacles,
                movesCount = newMoves,
                isLevelCompleted = levelWon,
                earnedStars = stars,
                canUndo = undoStack.isNotEmpty()
            )
        } else {
            // Collision: Arrow bumps into blocker!
            soundManager.playBump()
            val collisionDirection = traceResult.collisionDirection
            val updatedArrows = state.arrows.map {
                if (it.id == arrowId) {
                    it.copy(
                        isColliding = true,
                        collisionOffsetRow = collisionDirection.deltaRow * 0.28f,
                        collisionOffsetCol = collisionDirection.deltaCol * 0.28f
                    )
                } else it
            }
            _uiState.value = state.copy(arrows = updatedArrows)

            // Auto-reset collision bounce after 240ms
            viewModelScope.launch {
                delay(240L)
                val resetArrows = _uiState.value.arrows.map {
                    if (it.id == arrowId) {
                        it.copy(
                            isColliding = false,
                            collisionOffsetRow = 0f,
                            collisionOffsetCol = 0f
                        )
                    } else it
                }
                _uiState.value = _uiState.value.copy(arrows = resetArrows)
            }
        }
    }

    data class TraceResult(
        val canEscape: Boolean,
        val collisionDirection: ArrowDirection,
        val destroyedObstacleId: Int? = null
    )

    private fun tracePath(
        arrow: Arrow,
        arrows: List<Arrow>,
        obstacles: List<Obstacle>,
        maxRows: Int,
        maxCols: Int
    ): TraceResult {
        var currR = arrow.row
        var currC = arrow.col
        var currDir = arrow.direction
        var steps = 0

        val maxSteps = maxRows * maxCols * 2

        while (steps < maxSteps) {
            steps++

            // Handle turn arrow behavior: after 1 step, pivot 90 degrees
            if (steps == 2) {
                if (arrow.type == ArrowType.TURN_RIGHT) {
                    currDir = currDir.turnClockwise90()
                } else if (arrow.type == ArrowType.TURN_LEFT) {
                    currDir = currDir.turnCounterClockwise90()
                }
            }

            currR += currDir.deltaRow
            currC += currDir.deltaCol

            // Check if exited board boundaries
            if (currR !in 0 until maxRows || currC !in 0 until maxCols) {
                return TraceResult(canEscape = true, collisionDirection = currDir)
            }

            // Check collision with another arrow
            val blockingArrow = arrows.find { it.row == currR && it.col == currC && !it.isEscaped && it.id != arrow.id }
            if (blockingArrow != null) {
                return TraceResult(canEscape = false, collisionDirection = currDir)
            }

            // Check collision with obstacles
            val obstacle = obstacles.find { it.row == currR && it.col == currC && !it.isDestroyed }
            if (obstacle != null) {
                when (obstacle.type) {
                    ObstacleType.WALL -> {
                        if (arrow.type == ArrowType.BOMB) {
                            return TraceResult(canEscape = true, collisionDirection = currDir, destroyedObstacleId = obstacle.id)
                        }
                        return TraceResult(canEscape = false, collisionDirection = currDir)
                    }
                    ObstacleType.LOCK_DOOR -> {
                        return TraceResult(canEscape = false, collisionDirection = currDir)
                    }
                    ObstacleType.ROTATOR -> {
                        // Rotates arrow direction 90 degrees clockwise and continues
                        currDir = currDir.turnClockwise90()
                    }
                    ObstacleType.PORTAL_NODE -> {
                        // Teleport to twin portal!
                        if (obstacle.twinRow >= 0 && obstacle.twinCol >= 0) {
                            currR = obstacle.twinRow
                            currC = obstacle.twinCol
                        }
                    }
                }
            }
        }

        return TraceResult(canEscape = false, collisionDirection = currDir)
    }

    fun undo() {
        if (undoStack.isEmpty() || _uiState.value.isLevelCompleted) return
        soundManager.playClick()
        val lastStep = undoStack.removeAt(undoStack.lastIndex)
        _uiState.value = _uiState.value.copy(
            arrows = lastStep.previousArrows,
            obstacles = lastStep.previousObstacles,
            movesCount = maxOf(0, _uiState.value.movesCount - 1),
            canUndo = undoStack.isNotEmpty(),
            activeHintArrowId = null
        )
    }

    fun restartLevel() {
        soundManager.playClick()
        val levelNum = _uiState.value.currentLevelNumber
        startLevel(levelNum)
    }

    fun nextLevel() {
        soundManager.playClick()
        val next = _uiState.value.currentLevelNumber + 1
        if (next <= LevelCatalog.TOTAL_LEVELS) {
            startLevel(next)
        } else {
            navigateTo(AppScreen.LEVEL_SELECT)
        }
    }

    fun requestHint() {
        val state = _uiState.value
        if (state.isLevelCompleted) return

        // Find an unescaped arrow that can escape immediately
        val freeArrow = state.arrows.firstOrNull { arrow ->
            !arrow.isEscaped && tracePath(
                arrow,
                state.arrows,
                state.obstacles,
                state.levelData?.rows ?: 5,
                state.levelData?.cols ?: 5
            ).canEscape
        }

        if (freeArrow != null) {
            soundManager.playStar()
            viewModelScope.launch {
                repository.incrementHintUsed()
            }
            _uiState.value = state.copy(activeHintArrowId = freeArrow.id)
        } else {
            soundManager.playBump()
        }
    }

    fun toggleSound() {
        val newSound = !_uiState.value.soundEnabled
        soundManager.soundEnabled = newSound
        _uiState.value = _uiState.value.copy(soundEnabled = newSound)
        viewModelScope.launch {
            repository.updateSoundSetting(newSound)
        }
    }

    fun toggleHaptics() {
        val newHaptics = !_uiState.value.hapticsEnabled
        soundManager.hapticsEnabled = newHaptics
        _uiState.value = _uiState.value.copy(hapticsEnabled = newHaptics)
        viewModelScope.launch {
            repository.updateHapticsSetting(newHaptics)
        }
    }

    fun resetAllProgress() {
        soundManager.playClick()
        viewModelScope.launch {
            repository.resetAllProgress(LevelCatalog.TOTAL_LEVELS)
            _uiState.value = _uiState.value.copy(
                currentLevelNumber = 1,
                selectedWorldId = 1
            )
        }
    }

    // --- ARCADE MODE: ARROW RUSH ---
    fun startArcadeMode() {
        soundManager.playClick()
        val initialArrows = generateArcadeGrid()
        _uiState.value = _uiState.value.copy(
            currentScreen = AppScreen.ARCADE_MODE,
            isArcadeActive = true,
            arcadeScore = 0,
            arcadeStreak = 0,
            arcadeTimeRemaining = 60,
            arcadeGameOver = false,
            arrows = initialArrows,
            obstacles = emptyList()
        )
        startArcadeTimer()
    }

    private fun startArcadeTimer() {
        arcadeTimerJob?.cancel()
        arcadeTimerJob = viewModelScope.launch {
            while (_uiState.value.arcadeTimeRemaining > 0 && _uiState.value.isArcadeActive) {
                delay(1000L)
                val timeLeft = _uiState.value.arcadeTimeRemaining - 1
                if (timeLeft <= 0) {
                    soundManager.playVictory()
                    val finalScore = _uiState.value.arcadeScore
                    val finalStreak = _uiState.value.arcadeStreak
                    repository.saveArcadeHighScore(finalScore, finalStreak)
                    _uiState.value = _uiState.value.copy(
                        arcadeTimeRemaining = 0,
                        arcadeGameOver = true,
                        isArcadeActive = false
                    )
                } else {
                    _uiState.value = _uiState.value.copy(arcadeTimeRemaining = timeLeft)
                }
            }
        }
    }

    private fun stopArcadeTimer() {
        arcadeTimerJob?.cancel()
        arcadeTimerJob = null
    }

    fun onArcadeArrowTapped(arrowId: Int) {
        val state = _uiState.value
        if (state.arcadeGameOver || !state.isArcadeActive) return

        val arrow = state.arrows.find { it.id == arrowId && !it.isEscaped } ?: return
        val trace = tracePath(arrow, state.arrows, emptyList(), 4, 4)

        if (trace.canEscape) {
            soundManager.playLaunch()
            val newStreak = state.arcadeStreak + 1
            val points = 100 + (newStreak * 15)
            val newScore = state.arcadeScore + points

            // Mark escaped
            var currentList = state.arrows.map {
                if (it.id == arrowId) it.copy(isEscaped = true) else it
            }

            // Check if board needs refill
            if (currentList.count { !it.isEscaped } <= 3) {
                currentList = generateArcadeGrid()
            }

            _uiState.value = state.copy(
                arrows = currentList,
                arcadeScore = newScore,
                arcadeStreak = newStreak
            )
        } else {
            soundManager.playBump()
            _uiState.value = state.copy(arcadeStreak = 0)
        }
    }

    private fun generateArcadeGrid(): List<Arrow> {
        val levelData = LevelCatalog.generateSolvableLevel(
            levelNumber = (1..50).random(),
            worldId = 1,
            worldName = "Arcade Rush",
            title = "Arcade",
            rows = 4,
            cols = 4,
            targetArrowCount = 8
        )
        return levelData.arrows
    }
}
