package com.example.levels

import com.example.model.WorldInfo

object WorldDefinitions {
    val WORLDS: List<WorldInfo> = listOf(
        WorldInfo(
            id = 1,
            name = "Emerald Plains",
            subtitle = "The Fundamentals of Arrow Flow",
            startLevel = 1,
            endLevel = 10,
            primaryColorHex = 0xFF10B981, // Emerald Green
            accentColorHex = 0xFF34D399,
            iconName = "nature"
        ),
        WorldInfo(
            id = 2,
            name = "Sunfire Desert",
            subtitle = "Stone Barriers & Canyon Corridors",
            startLevel = 11,
            endLevel = 20,
            primaryColorHex = 0xFFF59E0B, // Amber Orange
            accentColorHex = 0xFFFCD34D,
            iconName = "terrain"
        ),
        WorldInfo(
            id = 3,
            name = "Cyber Matrix",
            subtitle = "Angular Turns & Rotator Pads",
            startLevel = 21,
            endLevel = 30,
            primaryColorHex = 0xFF06B6D4, // Neon Cyan
            accentColorHex = 0xFF67E8F9,
            iconName = "memory"
        ),
        WorldInfo(
            id = 4,
            name = "Arctic Frost",
            subtitle = "Subzero Portals & Slipstreams",
            startLevel = 31,
            endLevel = 40,
            primaryColorHex = 0xFF3B82F6, // Frost Blue
            accentColorHex = 0xFF93C5FD,
            iconName = "ac_unit"
        ),
        WorldInfo(
            id = 5,
            name = "Magma Core",
            subtitle = "Blast Bombs & Sealed Gates",
            startLevel = 41,
            endLevel = 50,
            primaryColorHex = 0xFFEF4444, // Magma Crimson
            accentColorHex = 0xFFFCA5A5,
            iconName = "local_fire_department"
        ),
        WorldInfo(
            id = 6,
            name = "Cosmic Infinity",
            subtitle = "Grandmaster Trials & Vortex Mazes",
            startLevel = 51,
            endLevel = 55,
            primaryColorHex = 0xFF8B5CF6, // Cosmic Purple
            accentColorHex = 0xFFC4B5FD,
            iconName = "all_inclusive"
        )
    )

    fun getWorldForLevel(levelNumber: Int): WorldInfo {
        return WORLDS.find { levelNumber in it.startLevel..it.endLevel } ?: WORLDS.last()
    }
}
