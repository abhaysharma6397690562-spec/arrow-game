package com.example.levels

import com.example.model.Arrow
import com.example.model.ArrowDirection
import com.example.model.ArrowType
import com.example.model.LevelData
import com.example.model.Obstacle
import com.example.model.ObstacleType
import kotlin.random.Random

object LevelCatalog {

    const val TOTAL_LEVELS = 55

    fun getLevel(levelNumber: Int): LevelData {
        val safeNum = levelNumber.coerceIn(1, TOTAL_LEVELS)
        return levelBuilders[safeNum]?.invoke() ?: generateProceduralLevel(safeNum, 5, 5, 12)
    }

    private val levelBuilders: Map<Int, () -> LevelData> = buildMap {
        // --- WORLD 1: EMERALD PLAINS (Levels 1 - 10) ---
        put(1) {
            LevelData(
                levelNumber = 1,
                worldId = 1,
                worldName = "Emerald Plains",
                title = "First Flight",
                rows = 3,
                cols = 3,
                parMoves = 3,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 1, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 3, row = 1, col = 2, direction = ArrowDirection.RIGHT)
                ),
                tutorialTip = "Tap an arrow to shoot it off the board. Clear all arrows to win!"
            )
        }

        put(2) {
            LevelData(
                levelNumber = 2,
                worldId = 1,
                worldName = "Emerald Plains",
                title = "Traffic Queue",
                rows = 3,
                cols = 3,
                parMoves = 3,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 1, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 3, row = 2, col = 1, direction = ArrowDirection.UP)
                ),
                tutorialTip = "Arrows cannot pass through other arrows. Release the front arrow first!"
            )
        }

        put(3) {
            LevelData(
                levelNumber = 3,
                worldId = 1,
                worldName = "Emerald Plains",
                title = "The Crossroad",
                rows = 3,
                cols = 3,
                parMoves = 4,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 1, col = 2, direction = ArrowDirection.RIGHT),
                    Arrow(id = 3, row = 2, col = 1, direction = ArrowDirection.DOWN),
                    Arrow(id = 4, row = 1, col = 1, direction = ArrowDirection.LEFT)
                ),
                tutorialTip = "Clear the perimeter arrows before launching the center arrow."
            )
        }

        put(4) {
            LevelData(
                levelNumber = 4,
                worldId = 1,
                worldName = "Emerald Plains",
                title = "Pinwheel",
                rows = 4,
                cols = 4,
                parMoves = 4,
                arrows = listOf(
                    Arrow(id = 1, row = 1, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 1, col = 2, direction = ArrowDirection.RIGHT),
                    Arrow(id = 3, row = 2, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 4, row = 2, col = 1, direction = ArrowDirection.LEFT)
                ),
                tutorialTip = "Each arrow has an unobstructed exit. Find which one can fly free!"
            )
        }

        put(5) {
            LevelData(
                levelNumber = 5,
                worldId = 1,
                worldName = "Emerald Plains",
                title = "Twin Streams",
                rows = 4,
                cols = 4,
                parMoves = 6,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 0, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 1, col = 0, direction = ArrowDirection.UP),
                    Arrow(id = 3, row = 2, col = 0, direction = ArrowDirection.UP),
                    Arrow(id = 4, row = 3, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 5, row = 2, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 6, row = 1, col = 3, direction = ArrowDirection.DOWN)
                )
            )
        }

        put(6) {
            LevelData(
                levelNumber = 6,
                worldId = 1,
                worldName = "Emerald Plains",
                title = "Spiral Core",
                rows = 4,
                cols = 4,
                parMoves = 6,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 1, direction = ArrowDirection.RIGHT),
                    Arrow(id = 2, row = 0, col = 2, direction = ArrowDirection.RIGHT),
                    Arrow(id = 3, row = 1, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 4, row = 2, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 5, row = 3, col = 2, direction = ArrowDirection.LEFT),
                    Arrow(id = 6, row = 2, col = 1, direction = ArrowDirection.UP)
                )
            )
        }

        put(7) {
            LevelData(
                levelNumber = 7,
                worldId = 1,
                worldName = "Emerald Plains",
                title = "Interlocking Teeth",
                rows = 4,
                cols = 4,
                parMoves = 7,
                arrows = listOf(
                    Arrow(id = 1, row = 1, col = 0, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 2, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 3, row = 1, col = 1, direction = ArrowDirection.RIGHT),
                    Arrow(id = 4, row = 2, col = 1, direction = ArrowDirection.DOWN),
                    Arrow(id = 5, row = 1, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 6, row = 2, col = 2, direction = ArrowDirection.RIGHT),
                    Arrow(id = 7, row = 3, col = 1, direction = ArrowDirection.DOWN)
                )
            )
        }

        put(8) {
            LevelData(
                levelNumber = 8,
                worldId = 1,
                worldName = "Emerald Plains",
                title = "Compass Rose",
                rows = 5,
                cols = 5,
                parMoves = 8,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 1, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 3, row = 2, col = 4, direction = ArrowDirection.RIGHT),
                    Arrow(id = 4, row = 2, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 5, row = 4, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 6, row = 3, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 7, row = 2, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 8, row = 2, col = 1, direction = ArrowDirection.LEFT)
                )
            )
        }

        put(9) {
            LevelData(
                levelNumber = 9,
                worldId = 1,
                worldName = "Emerald Plains",
                title = "The Woven Mat",
                rows = 4,
                cols = 4,
                parMoves = 8,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 0, direction = ArrowDirection.RIGHT),
                    Arrow(id = 2, row = 0, col = 2, direction = ArrowDirection.RIGHT),
                    Arrow(id = 3, row = 1, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 4, row = 3, col = 3, direction = ArrowDirection.LEFT),
                    Arrow(id = 5, row = 3, col = 1, direction = ArrowDirection.LEFT),
                    Arrow(id = 6, row = 2, col = 0, direction = ArrowDirection.UP),
                    Arrow(id = 7, row = 1, col = 1, direction = ArrowDirection.RIGHT),
                    Arrow(id = 8, row = 2, col = 2, direction = ArrowDirection.LEFT)
                )
            )
        }

        put(10) {
            LevelData(
                levelNumber = 10,
                worldId = 1,
                worldName = "Emerald Plains",
                title = "Valley Checkpoint",
                rows = 5,
                cols = 5,
                parMoves = 10,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 0, col = 3, direction = ArrowDirection.UP),
                    Arrow(id = 3, row = 1, col = 4, direction = ArrowDirection.RIGHT),
                    Arrow(id = 4, row = 3, col = 4, direction = ArrowDirection.RIGHT),
                    Arrow(id = 5, row = 4, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 6, row = 4, col = 1, direction = ArrowDirection.DOWN),
                    Arrow(id = 7, row = 3, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 8, row = 1, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 9, row = 2, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 10, row = 3, col = 2, direction = ArrowDirection.DOWN)
                )
            )
        }

        // --- WORLD 2: SUNFIRE DESERT (Levels 11 - 20) ---
        put(11) {
            LevelData(
                levelNumber = 11,
                worldId = 2,
                worldName = "Sunfire Desert",
                title = "Stone Pillars",
                rows = 4,
                cols = 4,
                parMoves = 5,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 2, row = 0, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 3, row = 1, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 4, row = 2, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 5, row = 3, col = 1, direction = ArrowDirection.LEFT)
                ),
                obstacles = listOf(
                    Obstacle(id = 101, row = 1, col = 2, type = ObstacleType.WALL),
                    Obstacle(id = 102, row = 2, col = 1, type = ObstacleType.WALL)
                ),
                tutorialTip = "Stone walls block arrow paths! Guide arrows safely past them."
            )
        }

        put(12) {
            LevelData(
                levelNumber = 12,
                worldId = 2,
                worldName = "Sunfire Desert",
                title = "Canyon Pass",
                rows = 4,
                cols = 4,
                parMoves = 6,
                arrows = listOf(
                    Arrow(id = 1, row = 1, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 2, row = 1, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 3, row = 1, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 4, row = 2, col = 1, direction = ArrowDirection.DOWN),
                    Arrow(id = 5, row = 2, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 6, row = 2, col = 3, direction = ArrowDirection.RIGHT)
                ),
                obstacles = listOf(
                    Obstacle(id = 103, row = 0, col = 0, type = ObstacleType.WALL),
                    Obstacle(id = 104, row = 3, col = 3, type = ObstacleType.WALL)
                )
            )
        }

        put(13) {
            LevelData(
                levelNumber = 13,
                worldId = 2,
                worldName = "Sunfire Desert",
                title = "Oasis Fort",
                rows = 5,
                cols = 5,
                parMoves = 7,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 2, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 3, row = 2, col = 4, direction = ArrowDirection.RIGHT),
                    Arrow(id = 4, row = 4, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 5, row = 1, col = 2, direction = ArrowDirection.LEFT),
                    Arrow(id = 6, row = 2, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 7, row = 3, col = 2, direction = ArrowDirection.RIGHT)
                ),
                obstacles = listOf(
                    Obstacle(id = 105, row = 2, col = 2, type = ObstacleType.WALL)
                )
            )
        }

        put(14) {
            LevelData(
                levelNumber = 14,
                worldId = 2,
                worldName = "Sunfire Desert",
                title = "Sand Dunes",
                rows = 5,
                cols = 5,
                parMoves = 8,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 1, col = 1, direction = ArrowDirection.LEFT),
                    Arrow(id = 3, row = 0, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 4, row = 2, col = 3, direction = ArrowDirection.UP),
                    Arrow(id = 5, row = 4, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 6, row = 3, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 7, row = 4, col = 1, direction = ArrowDirection.LEFT),
                    Arrow(id = 8, row = 2, col = 1, direction = ArrowDirection.DOWN)
                ),
                obstacles = listOf(
                    Obstacle(id = 106, row = 2, col = 2, type = ObstacleType.WALL),
                    Obstacle(id = 107, row = 1, col = 2, type = ObstacleType.WALL),
                    Obstacle(id = 108, row = 3, col = 2, type = ObstacleType.WALL)
                )
            )
        }

        put(15) {
            LevelData(
                levelNumber = 15,
                worldId = 2,
                worldName = "Sunfire Desert",
                title = "Sunstone Vault",
                rows = 5,
                cols = 5,
                parMoves = 9,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 2, row = 0, col = 4, direction = ArrowDirection.RIGHT),
                    Arrow(id = 3, row = 4, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 4, row = 4, col = 4, direction = ArrowDirection.RIGHT),
                    Arrow(id = 5, row = 1, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 6, row = 3, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 7, row = 2, col = 1, direction = ArrowDirection.LEFT),
                    Arrow(id = 8, row = 2, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 9, row = 2, col = 2, direction = ArrowDirection.UP)
                ),
                obstacles = listOf(
                    Obstacle(id = 109, row = 1, col = 1, type = ObstacleType.WALL),
                    Obstacle(id = 110, row = 1, col = 3, type = ObstacleType.WALL),
                    Obstacle(id = 111, row = 3, col = 1, type = ObstacleType.WALL),
                    Obstacle(id = 112, row = 3, col = 3, type = ObstacleType.WALL)
                )
            )
        }

        put(16) {
            LevelData(
                levelNumber = 16,
                worldId = 2,
                worldName = "Sunfire Desert",
                title = "Ancient Aqueduct",
                rows = 5,
                cols = 5,
                parMoves = 9,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 1, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 3, row = 2, col = 2, direction = ArrowDirection.RIGHT),
                    Arrow(id = 4, row = 2, col = 4, direction = ArrowDirection.RIGHT),
                    Arrow(id = 5, row = 3, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 6, row = 4, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 7, row = 2, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 8, row = 1, col = 0, direction = ArrowDirection.UP),
                    Arrow(id = 9, row = 3, col = 4, direction = ArrowDirection.DOWN)
                ),
                obstacles = listOf(
                    Obstacle(id = 113, row = 1, col = 1, type = ObstacleType.WALL),
                    Obstacle(id = 114, row = 3, col = 3, type = ObstacleType.WALL)
                )
            )
        }

        put(17) {
            LevelData(
                levelNumber = 17,
                worldId = 2,
                worldName = "Sunfire Desert",
                title = "Mirage Columns",
                rows = 5,
                cols = 5,
                parMoves = 10,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 1, col = 1, direction = ArrowDirection.LEFT),
                    Arrow(id = 3, row = 2, col = 1, direction = ArrowDirection.DOWN),
                    Arrow(id = 4, row = 3, col = 1, direction = ArrowDirection.LEFT),
                    Arrow(id = 5, row = 4, col = 1, direction = ArrowDirection.DOWN),
                    Arrow(id = 6, row = 0, col = 3, direction = ArrowDirection.UP),
                    Arrow(id = 7, row = 1, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 8, row = 2, col = 3, direction = ArrowDirection.UP),
                    Arrow(id = 9, row = 3, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 10, row = 4, col = 3, direction = ArrowDirection.DOWN)
                ),
                obstacles = listOf(
                    Obstacle(id = 115, row = 2, col = 2, type = ObstacleType.WALL)
                )
            )
        }

        put(18) {
            LevelData(
                levelNumber = 18,
                worldId = 2,
                worldName = "Sunfire Desert",
                title = "Pyramid Steps",
                rows = 5,
                cols = 5,
                parMoves = 10,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 1, col = 1, direction = ArrowDirection.LEFT),
                    Arrow(id = 3, row = 1, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 4, row = 2, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 5, row = 2, col = 4, direction = ArrowDirection.RIGHT),
                    Arrow(id = 6, row = 3, col = 1, direction = ArrowDirection.DOWN),
                    Arrow(id = 7, row = 3, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 8, row = 2, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 9, row = 3, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 10, row = 4, col = 2, direction = ArrowDirection.DOWN)
                ),
                obstacles = listOf(
                    Obstacle(id = 116, row = 1, col = 2, type = ObstacleType.WALL)
                )
            )
        }

        put(19) {
            LevelData(
                levelNumber = 19,
                worldId = 2,
                worldName = "Sunfire Desert",
                title = "Scorpion's Tail",
                rows = 5,
                cols = 5,
                parMoves = 11,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 0, direction = ArrowDirection.RIGHT),
                    Arrow(id = 2, row = 0, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 3, row = 1, col = 2, direction = ArrowDirection.LEFT),
                    Arrow(id = 4, row = 1, col = 0, direction = ArrowDirection.DOWN),
                    Arrow(id = 5, row = 3, col = 0, direction = ArrowDirection.RIGHT),
                    Arrow(id = 6, row = 3, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 7, row = 4, col = 2, direction = ArrowDirection.RIGHT),
                    Arrow(id = 8, row = 4, col = 4, direction = ArrowDirection.UP),
                    Arrow(id = 9, row = 2, col = 4, direction = ArrowDirection.LEFT),
                    Arrow(id = 10, row = 2, col = 3, direction = ArrowDirection.UP),
                    Arrow(id = 11, row = 0, col = 4, direction = ArrowDirection.RIGHT)
                )
            )
        }

        put(20) {
            LevelData(
                levelNumber = 20,
                worldId = 2,
                worldName = "Sunfire Desert",
                title = "Desert Stronghold",
                rows = 5,
                cols = 5,
                parMoves = 12,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 0, col = 3, direction = ArrowDirection.UP),
                    Arrow(id = 3, row = 1, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 4, row = 1, col = 4, direction = ArrowDirection.RIGHT),
                    Arrow(id = 5, row = 2, col = 1, direction = ArrowDirection.LEFT),
                    Arrow(id = 6, row = 2, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 7, row = 3, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 8, row = 3, col = 4, direction = ArrowDirection.RIGHT),
                    Arrow(id = 9, row = 4, col = 1, direction = ArrowDirection.DOWN),
                    Arrow(id = 10, row = 4, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 11, row = 1, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 12, row = 3, col = 2, direction = ArrowDirection.DOWN)
                ),
                obstacles = listOf(
                    Obstacle(id = 117, row = 2, col = 2, type = ObstacleType.WALL)
                )
            )
        }

        // --- WORLD 3: CYBER MATRIX (Levels 21 - 30) ---
        put(21) {
            LevelData(
                levelNumber = 21,
                worldId = 3,
                worldName = "Cyber Matrix",
                title = "Angular Circuit",
                rows = 4,
                cols = 4,
                parMoves = 4,
                arrows = listOf(
                    Arrow(id = 1, row = 1, col = 1, direction = ArrowDirection.UP, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 2, row = 1, col = 2, direction = ArrowDirection.RIGHT, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 3, row = 2, col = 2, direction = ArrowDirection.DOWN, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 4, row = 2, col = 1, direction = ArrowDirection.LEFT, type = ArrowType.TURN_RIGHT)
                ),
                tutorialTip = "Turn arrows travel 1 step then bend 90 degrees! Plan their curve."
            )
        }

        put(22) {
            LevelData(
                levelNumber = 22,
                worldId = 3,
                worldName = "Cyber Matrix",
                title = "Logic Gate",
                rows = 5,
                cols = 5,
                parMoves = 6,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 2, direction = ArrowDirection.LEFT, type = ArrowType.TURN_LEFT),
                    Arrow(id = 2, row = 2, col = 0, direction = ArrowDirection.DOWN, type = ArrowType.TURN_LEFT),
                    Arrow(id = 3, row = 4, col = 2, direction = ArrowDirection.RIGHT, type = ArrowType.TURN_LEFT),
                    Arrow(id = 4, row = 2, col = 4, direction = ArrowDirection.UP, type = ArrowType.TURN_LEFT),
                    Arrow(id = 5, row = 1, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 6, row = 3, col = 2, direction = ArrowDirection.DOWN)
                )
            )
        }

        put(23) {
            LevelData(
                levelNumber = 23,
                worldId = 3,
                worldName = "Cyber Matrix",
                title = "Data Highway",
                rows = 5,
                cols = 5,
                parMoves = 8,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 1, direction = ArrowDirection.DOWN, type = ArrowType.TURN_LEFT),
                    Arrow(id = 2, row = 0, col = 3, direction = ArrowDirection.DOWN, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 3, row = 4, col = 1, direction = ArrowDirection.UP, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 4, row = 4, col = 3, direction = ArrowDirection.UP, type = ArrowType.TURN_LEFT),
                    Arrow(id = 5, row = 2, col = 0, direction = ArrowDirection.RIGHT),
                    Arrow(id = 6, row = 2, col = 4, direction = ArrowDirection.LEFT),
                    Arrow(id = 7, row = 1, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 8, row = 3, col = 2, direction = ArrowDirection.DOWN)
                )
            )
        }

        put(24) {
            LevelData(
                levelNumber = 24,
                worldId = 3,
                worldName = "Cyber Matrix",
                title = "Quantum Grid",
                rows = 5,
                cols = 5,
                parMoves = 8,
                arrows = listOf(
                    Arrow(id = 1, row = 1, col = 1, direction = ArrowDirection.UP, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 2, row = 1, col = 3, direction = ArrowDirection.RIGHT, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 3, row = 3, col = 3, direction = ArrowDirection.DOWN, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 4, row = 3, col = 1, direction = ArrowDirection.LEFT, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 5, row = 0, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 6, row = 4, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 7, row = 2, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 8, row = 2, col = 4, direction = ArrowDirection.RIGHT)
                ),
                obstacles = listOf(
                    Obstacle(id = 118, row = 2, col = 2, type = ObstacleType.ROTATOR)
                ),
                tutorialTip = "Rotator tiles spin any arrow passing across them by 90 degrees!"
            )
        }

        put(25) {
            LevelData(
                levelNumber = 25,
                worldId = 3,
                worldName = "Cyber Matrix",
                title = "Subroutine Loop",
                rows = 5,
                cols = 5,
                parMoves = 10,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 0, direction = ArrowDirection.RIGHT),
                    Arrow(id = 2, row = 0, col = 3, direction = ArrowDirection.DOWN, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 3, row = 2, col = 3, direction = ArrowDirection.LEFT),
                    Arrow(id = 4, row = 2, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 5, row = 4, col = 4, direction = ArrowDirection.LEFT),
                    Arrow(id = 6, row = 4, col = 1, direction = ArrowDirection.UP, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 7, row = 3, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 8, row = 1, col = 4, direction = ArrowDirection.DOWN),
                    Arrow(id = 9, row = 1, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 10, row = 3, col = 0, direction = ArrowDirection.LEFT)
                )
            )
        }

        put(26) {
            LevelData(
                levelNumber = 26,
                worldId = 3,
                worldName = "Cyber Matrix",
                title = "Fiber Optic",
                rows = 5,
                cols = 5,
                parMoves = 10,
                arrows = listOf(
                    Arrow(id = 1, row = 1, col = 0, direction = ArrowDirection.RIGHT, type = ArrowType.TURN_LEFT),
                    Arrow(id = 2, row = 1, col = 4, direction = ArrowDirection.LEFT, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 3, row = 3, col = 0, direction = ArrowDirection.RIGHT, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 4, row = 3, col = 4, direction = ArrowDirection.LEFT, type = ArrowType.TURN_LEFT),
                    Arrow(id = 5, row = 0, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 6, row = 4, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 7, row = 2, col = 1, direction = ArrowDirection.LEFT),
                    Arrow(id = 8, row = 2, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 9, row = 2, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 10, row = 0, col = 0, direction = ArrowDirection.LEFT)
                )
            )
        }

        put(27) {
            LevelData(
                levelNumber = 27,
                worldId = 3,
                worldName = "Cyber Matrix",
                title = "Binary Tree",
                rows = 6,
                cols = 6,
                parMoves = 11,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 2, direction = ArrowDirection.LEFT),
                    Arrow(id = 2, row = 0, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 3, row = 1, col = 1, direction = ArrowDirection.UP, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 4, row = 1, col = 4, direction = ArrowDirection.UP, type = ArrowType.TURN_LEFT),
                    Arrow(id = 5, row = 2, col = 2, direction = ArrowDirection.LEFT),
                    Arrow(id = 6, row = 2, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 7, row = 3, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 8, row = 3, col = 5, direction = ArrowDirection.RIGHT),
                    Arrow(id = 9, row = 4, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 10, row = 4, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 11, row = 5, col = 2, direction = ArrowDirection.LEFT)
                )
            )
        }

        put(28) {
            LevelData(
                levelNumber = 28,
                worldId = 3,
                worldName = "Cyber Matrix",
                title = "Cyber Lattice",
                rows = 6,
                cols = 6,
                parMoves = 12,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 0, col = 4, direction = ArrowDirection.UP),
                    Arrow(id = 3, row = 1, col = 2, direction = ArrowDirection.LEFT, type = ArrowType.TURN_LEFT),
                    Arrow(id = 4, row = 1, col = 3, direction = ArrowDirection.RIGHT, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 5, row = 2, col = 0, direction = ArrowDirection.LEFT),
                    Arrow(id = 6, row = 2, col = 5, direction = ArrowDirection.RIGHT),
                    Arrow(id = 7, row = 3, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 8, row = 3, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 9, row = 4, col = 1, direction = ArrowDirection.LEFT),
                    Arrow(id = 10, row = 4, col = 4, direction = ArrowDirection.RIGHT),
                    Arrow(id = 11, row = 5, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 12, row = 5, col = 3, direction = ArrowDirection.DOWN)
                )
            )
        }

        put(29) {
            LevelData(
                levelNumber = 29,
                worldId = 3,
                worldName = "Cyber Matrix",
                title = "Processor Hub",
                rows = 6,
                cols = 6,
                parMoves = 13,
                arrows = listOf(
                    Arrow(id = 1, row = 1, col = 1, direction = ArrowDirection.UP),
                    Arrow(id = 2, row = 1, col = 4, direction = ArrowDirection.UP),
                    Arrow(id = 3, row = 4, col = 1, direction = ArrowDirection.DOWN),
                    Arrow(id = 4, row = 4, col = 4, direction = ArrowDirection.DOWN),
                    Arrow(id = 5, row = 2, col = 1, direction = ArrowDirection.RIGHT, type = ArrowType.TURN_LEFT),
                    Arrow(id = 6, row = 2, col = 4, direction = ArrowDirection.LEFT, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 7, row = 3, col = 1, direction = ArrowDirection.RIGHT, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 8, row = 3, col = 4, direction = ArrowDirection.LEFT, type = ArrowType.TURN_LEFT),
                    Arrow(id = 9, row = 0, col = 2, direction = ArrowDirection.LEFT),
                    Arrow(id = 10, row = 0, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 11, row = 5, col = 2, direction = ArrowDirection.LEFT),
                    Arrow(id = 12, row = 5, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 13, row = 2, col = 2, direction = ArrowDirection.UP)
                )
            )
        }

        put(30) {
            LevelData(
                levelNumber = 30,
                worldId = 3,
                worldName = "Cyber Matrix",
                title = "Firewall Overload",
                rows = 6,
                cols = 6,
                parMoves = 14,
                arrows = listOf(
                    Arrow(id = 1, row = 0, col = 0, direction = ArrowDirection.RIGHT),
                    Arrow(id = 2, row = 0, col = 5, direction = ArrowDirection.DOWN),
                    Arrow(id = 3, row = 5, col = 5, direction = ArrowDirection.LEFT),
                    Arrow(id = 4, row = 5, col = 0, direction = ArrowDirection.UP),
                    Arrow(id = 5, row = 1, col = 1, direction = ArrowDirection.RIGHT, type = ArrowType.TURN_RIGHT),
                    Arrow(id = 6, row = 1, col = 4, direction = ArrowDirection.DOWN, type = ArrowType.TURN_LEFT),
                    Arrow(id = 7, row = 4, col = 4, direction = ArrowDirection.LEFT, type = ArrowType.TURN_LEFT),
                    Arrow(id = 8, row = 4, col = 1, direction = ArrowDirection.UP, type = ArrowType.TURN_LEFT),
                    Arrow(id = 9, row = 2, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 10, row = 2, col = 3, direction = ArrowDirection.RIGHT),
                    Arrow(id = 11, row = 3, col = 3, direction = ArrowDirection.DOWN),
                    Arrow(id = 12, row = 3, col = 2, direction = ArrowDirection.LEFT),
                    Arrow(id = 13, row = 1, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 14, row = 4, col = 3, direction = ArrowDirection.DOWN)
                )
            )
        }

        // --- WORLD 4: ARCTIC FROST (Levels 31 - 40) ---
        put(31) {
            LevelData(
                levelNumber = 31,
                worldId = 4,
                worldName = "Arctic Frost",
                title = "Wormhole Gateway",
                rows = 5,
                cols = 5,
                parMoves = 5,
                arrows = listOf(
                    Arrow(id = 1, row = 2, col = 0, direction = ArrowDirection.RIGHT),
                    Arrow(id = 2, row = 0, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 3, row = 4, col = 2, direction = ArrowDirection.DOWN),
                    Arrow(id = 4, row = 1, col = 2, direction = ArrowDirection.UP),
                    Arrow(id = 5, row = 3, col = 2, direction = ArrowDirection.DOWN)
                ),
                obstacles = listOf(
                    Obstacle(id = 201, row = 2, col = 1, type = ObstacleType.PORTAL_NODE, colorIndex = 0, twinRow = 2, twinCol = 3),
                    Obstacle(id = 202, row = 2, col = 3, type = ObstacleType.PORTAL_NODE, colorIndex = 0, twinRow = 2, twinCol = 1)
                ),
                tutorialTip = "Arrows entering a portal teleport instantly out the matching portal!"
            )
        }

        // Generate levels 32 through 55 using structured builders
        for (lvl in 32..40) {
            put(lvl) {
                buildWorld4Level(lvl)
            }
        }

        // --- WORLD 5: MAGMA CORE (Levels 41 - 50) ---
        for (lvl in 41..50) {
            put(lvl) {
                buildWorld5Level(lvl)
            }
        }

        // --- WORLD 6: COSMIC INFINITY (Levels 51 - 55) ---
        for (lvl in 51..55) {
            put(lvl) {
                buildWorld6Level(lvl)
            }
        }
    }

    // World 4 Helper: Arctic Frost with Portals & Ice walls
    private fun buildWorld4Level(levelNum: Int): LevelData {
        val rows = 6
        val cols = 6
        val arrowCount = 8 + (levelNum - 31)
        val seed = levelNum * 31415L
        val rng = Random(seed)

        val obstacles = listOf(
            Obstacle(id = 301, row = 1, col = 1, type = ObstacleType.PORTAL_NODE, colorIndex = 0, twinRow = 4, twinCol = 4),
            Obstacle(id = 302, row = 4, col = 4, type = ObstacleType.PORTAL_NODE, colorIndex = 0, twinRow = 1, twinCol = 1),
            Obstacle(id = 303, row = 2, col = 3, type = ObstacleType.WALL)
        )

        return generateSolvableLevel(
            levelNumber = levelNum,
            worldId = 4,
            worldName = "Arctic Frost",
            title = when (levelNum) {
                32 -> "Glacier Rift"
                33 -> "Frost Portal"
                34 -> "Chilled Passage"
                35 -> "Icebound Nexus"
                36 -> "Permafrost Maze"
                37 -> "Blizzard Junction"
                38 -> "Aurora Crossing"
                39 -> "Crystal Spire"
                else -> "Frozen Citadel"
            },
            rows = rows,
            cols = cols,
            targetArrowCount = arrowCount,
            obstacles = obstacles,
            rng = rng,
            allowTurns = true
        )
    }

    // World 5 Helper: Magma Core with Bombs, Keys & Lock Doors
    private fun buildWorld5Level(levelNum: Int): LevelData {
        val rows = 6
        val cols = 6
        val arrowCount = 10 + (levelNum - 41)
        val seed = levelNum * 99233L
        val rng = Random(seed)

        val obstacles = listOf(
            Obstacle(id = 401, row = 2, col = 2, type = ObstacleType.LOCK_DOOR, colorIndex = 1),
            Obstacle(id = 402, row = 3, col = 3, type = ObstacleType.WALL)
        )

        val baseLevel = generateSolvableLevel(
            levelNumber = levelNum,
            worldId = 5,
            worldName = "Magma Core",
            title = when (levelNum) {
                41 -> "Blast Zone"
                42 -> "Molten Key"
                43 -> "Volcanic Chamber"
                44 -> "Lava Forge"
                45 -> "Searing Cross"
                46 -> "Brimstone Gate"
                47 -> "Obsidian Wall"
                48 -> "Eruption Path"
                49 -> "Inferno Core"
                else -> "Magma Overlord"
            },
            rows = rows,
            cols = cols,
            targetArrowCount = arrowCount,
            obstacles = obstacles,
            rng = rng,
            allowTurns = true,
            hasBombAndKey = true
        )

        return baseLevel
    }

    // World 6 Helper: Cosmic Infinity Master Challenges
    private fun buildWorld6Level(levelNum: Int): LevelData {
        val rows = 7
        val cols = 7
        val arrowCount = 14 + (levelNum - 51)
        val seed = levelNum * 77713L
        val rng = Random(seed)

        val obstacles = listOf(
            Obstacle(id = 501, row = 1, col = 2, type = ObstacleType.PORTAL_NODE, colorIndex = 0, twinRow = 5, twinCol = 4),
            Obstacle(id = 502, row = 5, col = 4, type = ObstacleType.PORTAL_NODE, colorIndex = 0, twinRow = 1, twinCol = 2),
            Obstacle(id = 503, row = 3, col = 3, type = ObstacleType.WALL),
            Obstacle(id = 504, row = 2, col = 4, type = ObstacleType.LOCK_DOOR, colorIndex = 2)
        )

        return generateSolvableLevel(
            levelNumber = levelNum,
            worldId = 6,
            worldName = "Cosmic Infinity",
            title = when (levelNum) {
                51 -> "Cosmic Singularity"
                52 -> "Galactic Labyrinth"
                53 -> "Supernova Matrix"
                54 -> "Dimension Warp"
                else -> "The Archer Supreme"
            },
            rows = rows,
            cols = cols,
            targetArrowCount = arrowCount,
            obstacles = obstacles,
            rng = rng,
            allowTurns = true,
            hasBombAndKey = true
        )
    }

    /**
     * Reverse-Construction Algorithm:
     * Generates a guaranteed 100% solvable level by starting from an empty board
     * and placing arrows in reverse order of clearance!
     * Because every placed arrow had an unobstructed path when inserted,
     * the puzzle is mathematically guaranteed to be solvable in reverse order.
     */
    fun generateSolvableLevel(
        levelNumber: Int,
        worldId: Int,
        worldName: String,
        title: String,
        rows: Int,
        cols: Int,
        targetArrowCount: Int,
        obstacles: List<Obstacle> = emptyList(),
        rng: Random = Random(levelNumber),
        allowTurns: Boolean = false,
        hasBombAndKey: Boolean = false
    ): LevelData {
        val occupied = Array(rows) { BooleanArray(cols) }
        obstacles.forEach {
            if (it.row in 0 until rows && it.col in 0 until cols) {
                occupied[it.row][it.col] = true
            }
        }

        val placedArrows = mutableListOf<Arrow>()
        val straightDirections = listOf(ArrowDirection.UP, ArrowDirection.DOWN, ArrowDirection.LEFT, ArrowDirection.RIGHT)

        var attempts = 0
        var idCounter = 1

        while (placedArrows.size < targetArrowCount && attempts < 250) {
            attempts++
            val r = rng.nextInt(rows)
            val c = rng.nextInt(cols)
            if (occupied[r][c]) continue

            // Pick a direction that has a clear path off the board given CURRENT placed arrows
            val possibleDirs = straightDirections.filter { dir ->
                isPathCurrentlyClear(r, c, dir, rows, cols, occupied)
            }

            if (possibleDirs.isNotEmpty()) {
                val chosenDir = possibleDirs[rng.nextInt(possibleDirs.size)]
                val arrowType = if (allowTurns && rng.nextFloat() < 0.25f) {
                    if (rng.nextBoolean()) ArrowType.TURN_RIGHT else ArrowType.TURN_LEFT
                } else if (hasBombAndKey && rng.nextFloat() < 0.15f) {
                    ArrowType.BOMB
                } else if (hasBombAndKey && rng.nextFloat() < 0.15f) {
                    ArrowType.KEY
                } else {
                    ArrowType.NORMAL
                }

                val arrow = Arrow(
                    id = idCounter++,
                    row = r,
                    col = c,
                    direction = chosenDir,
                    type = arrowType,
                    colorIndex = rng.nextInt(5)
                )
                placedArrows.add(arrow)
                occupied[r][c] = true
            }
        }

        // If not enough placed, fill with perimeter arrows that point outwards
        if (placedArrows.size < 6) {
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if (!occupied[r][c] && placedArrows.size < targetArrowCount) {
                        val dir = when {
                            r == 0 -> ArrowDirection.UP
                            r == rows - 1 -> ArrowDirection.DOWN
                            c == 0 -> ArrowDirection.LEFT
                            c == cols - 1 -> ArrowDirection.RIGHT
                            else -> straightDirections[rng.nextInt(straightDirections.size)]
                        }
                        placedArrows.add(
                            Arrow(
                                id = idCounter++,
                                row = r,
                                col = c,
                                direction = dir,
                                colorIndex = rng.nextInt(5)
                            )
                        )
                        occupied[r][c] = true
                    }
                }
            }
        }

        return LevelData(
            levelNumber = levelNumber,
            worldId = worldId,
            worldName = worldName,
            title = title,
            rows = rows,
            cols = cols,
            parMoves = placedArrows.size,
            arrows = placedArrows,
            obstacles = obstacles
        )
    }

    private fun isPathCurrentlyClear(
        startR: Int,
        startC: Int,
        dir: ArrowDirection,
        maxR: Int,
        maxC: Int,
        occupied: Array<BooleanArray>
    ): Boolean {
        var currR = startR + dir.deltaRow
        var currC = startC + dir.deltaCol

        while (currR in 0 until maxR && currC in 0 until maxC) {
            if (occupied[currR][currC]) {
                return false
            }
            currR += dir.deltaRow
            currC += dir.deltaCol
        }
        return true
    }

    fun generateProceduralLevel(levelNum: Int, rows: Int = 5, cols: Int = 5, count: Int = 12): LevelData {
        val world = WorldDefinitions.getWorldForLevel(levelNum)
        return generateSolvableLevel(
            levelNumber = levelNum,
            worldId = world.id,
            worldName = world.name,
            title = "Level $levelNum",
            rows = rows,
            cols = cols,
            targetArrowCount = count,
            rng = Random(levelNum * 4391L)
        )
    }
}
