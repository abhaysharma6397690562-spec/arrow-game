package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AppScreen
import com.example.ui.components.StatsDialog
import com.example.ui.screens.ArcadeScreen
import com.example.ui.screens.GameScreen
import com.example.ui.screens.MenuScreen
import com.example.ui.screens.WorldLevelSelectScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ArrowGameApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun ArrowGameApp(viewModel: GameViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val progressList by viewModel.allProgress.collectAsStateWithLifecycle()
    val profile by viewModel.playerProfile.collectAsStateWithLifecycle()

    var showStatsDialog by remember { mutableStateOf(false) }

    when (uiState.currentScreen) {
        AppScreen.MENU -> {
            MenuScreen(
                progressList = progressList,
                profile = profile,
                soundEnabled = uiState.soundEnabled,
                hapticsEnabled = uiState.hapticsEnabled,
                onContinueGame = { levelNum ->
                    viewModel.startLevel(levelNum)
                },
                onOpenLevelSelect = {
                    viewModel.navigateTo(AppScreen.LEVEL_SELECT)
                },
                onStartArcade = {
                    viewModel.startArcadeMode()
                },
                onOpenStats = {
                    showStatsDialog = true
                },
                onToggleSound = {
                    viewModel.toggleSound()
                },
                onToggleHaptics = {
                    viewModel.toggleHaptics()
                }
            )
        }

        AppScreen.LEVEL_SELECT -> {
            WorldLevelSelectScreen(
                selectedWorldId = uiState.selectedWorldId,
                progressList = progressList,
                onSelectWorld = { worldId ->
                    viewModel.selectWorld(worldId)
                },
                onSelectLevel = { levelNum ->
                    viewModel.startLevel(levelNum)
                },
                onNavigateBack = {
                    viewModel.navigateTo(AppScreen.MENU)
                }
            )
        }

        AppScreen.GAME -> {
            GameScreen(
                state = uiState,
                onArrowTapped = { arrowId ->
                    viewModel.onArrowTapped(arrowId)
                },
                onUndo = {
                    viewModel.undo()
                },
                onRestart = {
                    viewModel.restartLevel()
                },
                onRequestHint = {
                    viewModel.requestHint()
                },
                onNextLevel = {
                    viewModel.nextLevel()
                },
                onToggleSound = {
                    viewModel.toggleSound()
                },
                onNavigateBack = {
                    viewModel.navigateTo(AppScreen.LEVEL_SELECT)
                }
            )
        }

        AppScreen.ARCADE_MODE -> {
            ArcadeScreen(
                state = uiState,
                profile = profile,
                onArrowTapped = { arrowId ->
                    viewModel.onArcadeArrowTapped(arrowId)
                },
                onRestartArcade = {
                    viewModel.startArcadeMode()
                },
                onNavigateBack = {
                    viewModel.navigateTo(AppScreen.MENU)
                }
            )
        }

        AppScreen.STATS -> {
            // Handled via dialog
            viewModel.navigateTo(AppScreen.MENU)
        }
    }

    if (showStatsDialog) {
        StatsDialog(
            progressList = progressList,
            profile = profile,
            onDismiss = { showStatsDialog = false },
            onResetProgress = {
                viewModel.resetAllProgress()
            }
        )
    }
}
