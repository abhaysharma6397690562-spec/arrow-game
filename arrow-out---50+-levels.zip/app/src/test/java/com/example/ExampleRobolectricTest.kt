package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.levels.LevelCatalog
import com.example.levels.WorldDefinitions
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Arrow Out", appName)
    }

    @Test
    fun `verify level catalog has 55 levels`() {
        assertEquals(55, LevelCatalog.TOTAL_LEVELS)
        for (i in 1..55) {
            val level = LevelCatalog.getLevel(i)
            assertNotNull("Level $i should not be null", level)
            assertEquals(i, level.levelNumber)
            assertTrue("Level $i should have arrows", level.arrows.isNotEmpty())
        }
    }

    @Test
    fun `verify world definitions`() {
        assertEquals(6, WorldDefinitions.WORLDS.size)
        val w1 = WorldDefinitions.getWorldForLevel(1)
        assertEquals(1, w1.id)
        val w6 = WorldDefinitions.getWorldForLevel(55)
        assertEquals(6, w6.id)
    }
}
